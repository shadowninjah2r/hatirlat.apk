package com.example.hatirlat;

import android.app.Activity;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        String message = getIntent().getStringExtra("message");
        if (message == null || message.trim().isEmpty()) {
            message = "Hatırlatma zamanı geldi!";
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(32), dp(28), dp(32));
        root.setBackgroundColor(Color.rgb(8, 6, 13));

        TextView title = new TextView(this);
        title.setText("HATIRLAT");
        title.setTextColor(Color.rgb(202, 145, 255));
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView reminder = new TextView(this);
        reminder.setText(message);
        reminder.setTextColor(Color.WHITE);
        reminder.setTextSize(27);
        reminder.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reminder.setGravity(Gravity.CENTER);
        reminder.setPadding(dp(12), dp(30), dp(12), dp(30));
        LinearLayout.LayoutParams reminderParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        reminderParams.topMargin = dp(20);
        reminderParams.bottomMargin = dp(30);
        root.addView(reminder, reminderParams);

        Button dismiss = new Button(this);
        dismiss.setText("TAMAM, KAPAT");
        dismiss.setTextColor(Color.WHITE);
        dismiss.setTextSize(15);
        dismiss.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        dismiss.setAllCaps(false);
        GradientDrawable button = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { Color.rgb(117, 48, 181), Color.rgb(155, 75, 220) });
        button.setCornerRadius(dp(16));
        dismiss.setBackground(button);
        root.addView(dismiss, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        dismiss.setOnClickListener(v -> {
            NotificationManager manager = (NotificationManager)
                    getSystemService(NOTIFICATION_SERVICE);
            manager.cancel(1001);
            finish();
        });

        setContentView(root);
    }
}
