package com.example.hatirlat;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATIONS = 701;
    private static final int REQ_EXACT_ALARM = 702;
    private static final int REQ_FULL_SCREEN = 703;
    private EditText messageInput;
    private TimePicker timePicker;
    private TextView statusText;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 6, 13));
        getWindow().setNavigationBarColor(Color.rgb(8, 6, 13));
        createNotificationChannel();
        buildUi();
        askForNotificationPermissionIfNeeded();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(8, 6, 13));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("HATIRLAT");
        title.setTextColor(Color.rgb(202, 145, 255));
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Zamanı gelince ekranda göster.");
        subtitle.setTextColor(Color.rgb(178, 169, 194));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = dp(6);
        subParams.bottomMargin = dp(24);
        root.addView(subtitle, subParams);

        TextView messageLabel = label("HATIRLATMA METNİ");
        root.addView(messageLabel, matchWrap());

        messageInput = new EditText(this);
        messageInput.setTextColor(Color.WHITE);
        messageInput.setHintTextColor(Color.rgb(142, 132, 157));
        messageInput.setHint("Örn. Ödevini kontrol et");
        messageInput.setTextSize(16);
        messageInput.setMinLines(2);
        messageInput.setGravity(Gravity.TOP | Gravity.START);
        messageInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        messageInput.setBackground(panelBackground());
        LinearLayout.LayoutParams inputParams = matchWrap();
        inputParams.topMargin = dp(8);
        inputParams.bottomMargin = dp(22);
        root.addView(messageInput, inputParams);

        root.addView(label("SAAT"), matchWrap());
        timePicker = new TimePicker(this);
        timePicker.setIs24HourView(true);
        LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        timeParams.gravity = Gravity.CENTER_HORIZONTAL;
        timeParams.topMargin = dp(6);
        timeParams.bottomMargin = dp(18);
        root.addView(timePicker, timeParams);

        Button saveButton = new Button(this);
        saveButton.setText("HATIRLATICI KUR");
        saveButton.setTextColor(Color.WHITE);
        saveButton.setTextSize(15);
        saveButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        saveButton.setAllCaps(false);
        saveButton.setBackground(buttonBackground());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        root.addView(saveButton, buttonParams);
        saveButton.setOnClickListener(v -> scheduleReminder());

        statusText = new TextView(this);
        statusText.setText("Hatırlatmanı yaz, saati seç ve kur.");
        statusText.setTextColor(Color.rgb(184, 166, 207));
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(18);
        root.addView(statusText, statusParams);

        TextView note = new TextView(this);
        note.setText("Tam ekran gösterimi için Android bildirim ve tam ekran alarm izinleri gerekebilir.");
        note.setTextColor(Color.rgb(125, 117, 139));
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(20);
        root.addView(note, noteParams);

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private TextView label(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(194, 159, 230));
        view.setTextSize(12);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable panelBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.rgb(22, 17, 31));
        drawable.setCornerRadius(dp(14));
        drawable.setStroke(dp(1), Color.rgb(111, 55, 160));
        return drawable;
    }

    private GradientDrawable buttonBackground() {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { Color.rgb(117, 48, 181), Color.rgb(155, 75, 220) });
        drawable.setCornerRadius(dp(16));
        return drawable;
    }

    private void askForNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, REQ_NOTIFICATIONS);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(
                    AlarmReceiver.CHANNEL_ID, "HATIRLAT alarmları",
                    android.app.NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Zamanı gelen hatırlatmalar");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            android.app.NotificationManager manager = getSystemService(android.app.NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void scheduleReminder() {
        String message = messageInput.getText().toString().trim();
        if (message.isEmpty()) {
            messageInput.setError("Bir hatırlatma metni yaz.");
            return;
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            statusText.setText("Önce bildirim iznini ver, sonra hatırlatıcıyı tekrar kur.");
            askForNotificationPermissionIfNeeded();
            return;
        }

        if (Build.VERSION.SDK_INT >= 34) {
            android.app.NotificationManager notificationManager =
                    getSystemService(android.app.NotificationManager.class);
            if (!notificationManager.canUseFullScreenIntent()) {
                statusText.setText("Açılan ayarlarda HATIRLAT için tam ekran alarm iznini ver, sonra tekrar kur.");
                Intent fullScreenSettings = new Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(fullScreenSettings, REQ_FULL_SCREEN);
                return;
            }
        }

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            statusText.setText("Açılan ayarlarda HATIRLAT için alarm iznini ver, sonra tekrar kur.");
            Intent settingsIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(settingsIntent, REQ_EXACT_ALARM);
            return;
        }

        Calendar target = Calendar.getInstance();
        target.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
        target.set(Calendar.MINUTE, timePicker.getMinute());
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);
        if (!target.getTime().after(new Date())) {
            target.add(Calendar.DAY_OF_YEAR, 1);
        }

        SharedPreferences prefs = getSharedPreferences("hatirlat", MODE_PRIVATE);
        prefs.edit().putString("reminder_text", message)
                .putLong("reminder_time", target.getTimeInMillis()).apply();

        Intent alarmIntent = new Intent(this, AlarmReceiver.class);
        PendingIntent alarmPendingIntent = PendingIntent.getBroadcast(
                this, 1, alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent showPendingIntent = PendingIntent.getActivity(
                this, 2, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        alarmManager.setAlarmClock(
                new AlarmManager.AlarmClockInfo(target.getTimeInMillis(), showPendingIntent),
                alarmPendingIntent);

        String formatted = new SimpleDateFormat("dd MMM, HH:mm", new Locale("tr", "TR"))
                .format(target.getTime());
        statusText.setText("Kuruldu: " + formatted + "\n" + message);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXACT_ALARM || requestCode == REQ_FULL_SCREEN) {
            statusText.setText("İzin durumunu kontrol ettim. Hatırlatıcıyı kurmak için düğmeye tekrar bas.");
        }
    }
}
