# HATIRLAT Android

HATIRLAT is a small personal Android reminder app with a black/purple theme.

## Features
- Set a reminder message and time.
- Uses Android's alarm scheduler.
- At the due time, posts a high-priority alarm notification with a full-screen reminder activity.
- The reminder screen shows the text in the center and has a dismiss button.

## Requirements
- Android 8.0 (API 26) or newer.
- Android SDK 35 and JDK 17 for building.

## Important Android permissions
The app needs notification permission and exact-alarm access. On newer Android versions, full-screen notifications can also be controlled by system settings. If the screen does not open automatically, enable HATIRLAT's full-screen notifications/alarms in Android settings and test again.

This is a fresh source project, not a recovered copy of the old ZIP. It is configured to use Java 17 and contains no Kotlin source, so the earlier Java/Kotlin JVM-target mismatch is avoided.
